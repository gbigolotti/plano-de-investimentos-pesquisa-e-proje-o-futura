# 🧾 Ferramenta de Apoio para Declaração de Imposto de Renda - Projeto DIO

Este repositório contém uma planilha Excel desenvolvida como parte do desafio da DIO. O objetivo é oferecer uma solução prática e eficiente para organizar os dados necessários à declaração do Imposto de Renda Pessoa Física (IRPF).

## 📌 Descrição do Projeto

A ferramenta permite o controle centralizado de rendimentos, despesas, bens, dívidas e outras informações relevantes, com validações automáticas, navegação simplificada e integração com links úteis da Receita Federal.

## 🎯 Funcionalidades

✅ Dashboard inicial com links de navegação  
✅ Validação automática de campos (como CPF, datas e valores)  
✅ Controle de categorias essenciais para o IR:  
  - Rendimentos Tributáveis e Isentos  
  - Bens e Direitos  
  - Dívidas e Ônus  
  - Pagamentos e Doações  
✅ Resumo consolidado em formato de tabela dinâmica  
✅ Hiperlinks para orientações oficiais da Receita Federal  

## 🧪 Tecnologias Utilizadas

- Microsoft Excel (fórmulas, validações, tabelas dinâmicas)
- Git e GitHub para versionamento e documentação
- Markdown para escrita técnica

## 🗂️ Estrutura da Planilha

| Aba                  | Finalidade                                                 |
|----------------------|------------------------------------------------------------|
| Dashboard            | Navegação geral e resumo visual                            |
| Rendimentos          | Registro detalhado de rendimentos tributáveis e isentos    |
| Despesas             | Gasto com saúde, educação, pensão, etc.                    |
| Bens e Direitos      | Controle de veículos, imóveis, contas, investimentos       |
| Dívidas e Ônus       | Financiamentos, empréstimos e afins                        |
| Resumo IR            | Consolidação automática dos dados inseridos                |
| Links Úteis          | Acesso rápido à Receita Federal e fontes de consulta       |

## 📸 Capturas de Tela

### Dashboard com Navegação
![Dashboard](images/dashboard.png)

### Validação de Dados
![Validações](images/validacoes.png)

### Resumo Consolidado
![Resumo](images/resumo_dados.png)

## 🚀 Como Usar

1. Faça o download do arquivo `Ferramenta_IR_DIO.xlsx`
2. Abra no Excel (preferencialmente 2016 ou superior)
3. Comece pelo **Dashboard**
4. Preencha as abas conforme os campos indicados
5. Utilize a aba **Resumo IR** para visualizar um consolidado dos dados

> **Importante**: Sempre revise seus dados antes de importar para o sistema da Receita Federal.

## 🔗 Recursos Úteis

- [Documentação do GitHub](https://docs.github.com/pt)
- [Guia Markdown no GitHub](https://docs.github.com/pt/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)
- [Formação GitHub - GitBook](https://aline-antunes.gitbook.io/formacao-fundamentos-github)
- [Criar VM no Azure](https://learn.microsoft.com/pt-br/azure/virtual-machines/windows/quick-create-portal)

## 🤝 Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para fazer um fork do repositório e enviar um pull request.

## 🧠 Autor

Desenvolvido por [Seu Nome Aqui]  
Como parte do desafio da DIO - Formação Excel Power Data

---

**Projeto Educacional - DIO - Formação Excel Power Data**
